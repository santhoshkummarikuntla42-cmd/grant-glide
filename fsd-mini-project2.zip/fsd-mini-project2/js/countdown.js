/**
 * ScholarQuest - Live Application Deadline Countdown Tracker
 * 
 * Computes and renders real-time countdown clocks (Days, Hours, Minutes, Seconds)
 * with dynamic urgency level classifications and visual warning badges:
 * - CRITICAL: < 7 Days Remaining (Pulsing Red)
 * - URGENT: 7 - 14 Days Remaining (Orange)
 * - CLOSING SOON: 15 - 30 Days Remaining (Amber)
 * - ACTIVE: > 30 Days Remaining (Emerald Green)
 */

const CountdownEngine = (() => {
  // Store reference date computed on session start so deadlines stay persistent during session
  const sessionStartTime = Date.now();

  /**
   * Resolves the target deadline timestamp for a scholarship.
   * If `deadlineDaysFromNow` is provided, anchors to session start + days * 24h.
   */
  function getDeadlineTimestamp(scheme) {
    if (scheme.deadlineDaysFromNow !== undefined) {
      // Calculate target time: session start + days
      return sessionStartTime + (scheme.deadlineDaysFromNow * 24 * 60 * 60 * 1000);
    }
    if (scheme.deadline) {
      return new Date(scheme.deadline).getTime();
    }
    // Default fallback to 14 days
    return sessionStartTime + (14 * 24 * 60 * 60 * 1000);
  }

  /**
   * Computes time remaining between now and the deadline.
   * @param {number} deadlineTimestamp 
   * @returns {Object} { totalMs, days, hours, minutes, seconds, isExpired }
   */
  function getTimeRemaining(deadlineTimestamp) {
    const totalMs = deadlineTimestamp - Date.now();

    if (totalMs <= 0) {
      return { totalMs: 0, days: 0, hours: 0, minutes: 0, seconds: 0, isExpired: true };
    }

    const seconds = Math.floor((totalMs / 1000) % 60);
    const minutes = Math.floor((totalMs / 1000 / 60) % 60);
    const hours = Math.floor((totalMs / (1000 * 60 * 60)) % 24);
    const days = Math.floor(totalMs / (1000 * 60 * 60 * 24));

    return { totalMs, days, hours, minutes, seconds, isExpired: false };
  }

  /**
   * Determines urgency classification based on remaining days.
   * @param {number} days 
   * @returns {Object} { level, label, badgeClass, icon }
   */
  function getUrgencyMetadata(days) {
    if (days < 7) {
      return {
        level: 'critical',
        label: 'CRITICAL DEADLINE',
        badgeClass: 'badge-urgency-critical',
        pillClass: 'timer-critical',
        icon: '🚨'
      };
    } else if (days < 15) {
      return {
        level: 'urgent',
        label: 'URGENT',
        badgeClass: 'badge-urgency-urgent',
        pillClass: 'timer-urgent',
        icon: '⏳'
      };
    } else if (days < 30) {
      return {
        level: 'closing-soon',
        label: 'CLOSING SOON',
        badgeClass: 'badge-urgency-warning',
        pillClass: 'timer-warning',
        icon: '⏱️'
      };
    } else {
      return {
        level: 'active',
        label: 'ACTIVE / OPEN',
        badgeClass: 'badge-urgency-active',
        pillClass: 'timer-active',
        icon: '✅'
      };
    }
  }

  /**
   * Generates formatted HTML for countdown badge and timer digits.
   */
  function renderCountdownHTML(scheme) {
    const targetMs = getDeadlineTimestamp(scheme);
    const remaining = getTimeRemaining(targetMs);
    const urgency = getUrgencyMetadata(remaining.days);

    if (remaining.isExpired) {
      return `
        <div class="deadline-block">
          <span class="badge badge-expired">⚠️ Portal Closed</span>
        </div>
      `;
    }

    return `
      <div class="deadline-block" data-scheme-id="${scheme.id}" data-deadline="${targetMs}">
        <div class="urgency-header">
          <span class="urgency-badge ${urgency.badgeClass}">
            <span class="urgency-dot"></span>
            ${urgency.icon} ${urgency.label} (${remaining.days} Days Remaining)
          </span>
        </div>
        <div class="countdown-clock ${urgency.pillClass}">
          <div class="clock-unit">
            <span class="digit digit-days">${String(remaining.days).padStart(2, '0')}</span>
            <span class="label">Days</span>
          </div>
          <span class="clock-separator">:</span>
          <div class="clock-unit">
            <span class="digit digit-hours">${String(remaining.hours).padStart(2, '0')}</span>
            <span class="label">Hours</span>
          </div>
          <span class="clock-separator">:</span>
          <div class="clock-unit">
            <span class="digit digit-minutes">${String(remaining.minutes).padStart(2, '0')}</span>
            <span class="label">Mins</span>
          </div>
          <span class="clock-separator">:</span>
          <div class="clock-unit">
            <span class="digit digit-seconds">${String(remaining.seconds).padStart(2, '0')}</span>
            <span class="label">Secs</span>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Initializes real-time live clock interval that updates all rendered countdown cards on the page.
   */
  let intervalHandle = null;

  function startLiveTicking() {
    if (intervalHandle) {
      clearInterval(intervalHandle);
    }

    intervalHandle = setInterval(() => {
      const blocks = document.querySelectorAll('.deadline-block[data-deadline]');
      blocks.forEach(block => {
        const targetMs = Number(block.getAttribute('data-deadline'));
        const remaining = getTimeRemaining(targetMs);

        const daysEl = block.querySelector('.digit-days');
        const hoursEl = block.querySelector('.digit-hours');
        const minsEl = block.querySelector('.digit-minutes');
        const secsEl = block.querySelector('.digit-seconds');

        if (daysEl && hoursEl && minsEl && secsEl) {
          daysEl.textContent = String(remaining.days).padStart(2, '0');
          hoursEl.textContent = String(remaining.hours).padStart(2, '0');
          minsEl.textContent = String(remaining.minutes).padStart(2, '0');
          secsEl.textContent = String(remaining.seconds).padStart(2, '0');
        }
      });
    }, 1000);
  }

  return {
    getDeadlineTimestamp,
    getTimeRemaining,
    getUrgencyMetadata,
    renderCountdownHTML,
    startLiveTicking
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = CountdownEngine;
}
