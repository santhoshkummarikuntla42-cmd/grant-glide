/**
 * ScholarQuest - Saved & Applied Scholarship Pipeline Tracker
 * 
 * Features:
 * - Application lifecycle tracking across 4 main stages:
 *   [ Bookmarked | Applied | Under Review | Awarded ]
 * - Dual-Availing Policy Conflict Detector:
 *   Detects when students add mutually exclusive government scholarships
 *   (e.g., Central Sector Scheme + State ePASS Tuition Reimbursement)
 *   and outputs actionable compliance advice.
 * - Local persistence + optional server synchronization.
 */

const ApplicationTracker = (() => {
  const STORAGE_KEY = 'scholarquest_user_applications';

  // Seed with one or two initial items for demo
  const initialApplications = [
    {
      id: 'aicte-pragati',
      title: 'AICTE Pragati Scholarship for Girls',
      category: 'Women in STEM',
      schemeType: 'Government',
      awardFormatted: '₹50,000 / year',
      awardAmount: 50000,
      policyConflictGroup: 'CENTRAL_GOVT_SCHEME',
      status: 'Bookmarked',
      portalUrl: 'https://www.aicte-pragati-saksham-gov.in',
      deadlineDaysFromNow: 12,
      appliedDate: null,
      notes: 'Eligible for 1st year B.Tech girls. Checklist ready 3/5.'
    }
  ];

  let applications = [];

  function init() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        applications = JSON.parse(saved);
      } catch (e) {
        applications = [...initialApplications];
      }
    } else {
      applications = [...initialApplications];
      save();
    }
  }

  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(applications));
  }

  function getApplications() {
    return applications;
  }

  function getApplicationById(id) {
    return applications.find(a => a.id === id);
  }

  /**
   * Adds or bookmarks a scholarship.
   */
  function addApplication(scheme, status = 'Bookmarked') {
    const existing = applications.find(a => a.id === scheme.id);
    if (existing) {
      existing.status = status;
      existing.updatedAt = new Date().toISOString();
    } else {
      applications.push({
        id: scheme.id,
        title: scheme.title,
        category: scheme.category,
        schemeType: scheme.schemeType,
        awardFormatted: scheme.awardFormatted,
        awardAmount: scheme.awardAmount,
        policyConflictGroup: scheme.policyConflictGroup,
        status: status,
        portalUrl: scheme.portalUrl,
        deadlineDaysFromNow: scheme.deadlineDaysFromNow,
        appliedDate: status === 'Applied' ? new Date().toISOString().split('T')[0] : null,
        notes: '',
        createdAt: new Date().toISOString()
      });
    }
    save();
    return checkPolicyConflicts();
  }

  /**
   * Updates stage of an existing application.
   */
  function updateStatus(id, newStatus) {
    const app = applications.find(a => a.id === id);
    if (app) {
      app.status = newStatus;
      if (newStatus === 'Applied' && !app.appliedDate) {
        app.appliedDate = new Date().toISOString().split('T')[0];
      }
      app.updatedAt = new Date().toISOString();
      save();
    }
    return checkPolicyConflicts();
  }

  /**
   * Removes application from pipeline.
   */
  function removeApplication(id) {
    applications = applications.filter(a => a.id !== id);
    save();
    return checkPolicyConflicts();
  }

  /**
   * Evaluates dual-availing rules and detects conflicting government schemes.
   * Central Guidelines Rule: A student cannot receive concurrent tuition reimbursement
   * from more than one government (Central or State) scheme for the same degree.
   */
  function checkPolicyConflicts() {
    const active = applications.filter(a => ['Bookmarked', 'Applied', 'Under Review', 'Awarded'].includes(a.status));
    const conflicts = [];

    const centralSchemes = active.filter(a => a.policyConflictGroup === 'CENTRAL_GOVT_SCHEME' || a.policyConflictGroup === 'CENTRAL_POST_MATRIC');
    const stateSchemes = active.filter(a => a.policyConflictGroup === 'STATE_EPASS_SCHEME');

    if (centralSchemes.length > 0 && stateSchemes.length > 0) {
      conflicts.push({
        id: 'central-state-conflict',
        title: '⚠️ Policy Conflict: Simultaneous Central & State Tuition Subsidies Detected',
        schemesInvolved: [...centralSchemes.map(s => s.title), ...stateSchemes.map(s => s.title)],
        severity: 'high',
        summary: 'Under Ministry of Education & State Social Welfare norms, students are prohibited from drawing concurrent full tuition fee reimbursements from both Central and State government portals.',
        recommendation: 'Opt for your State ePASS scheme for 100% college tuition waiver, plus combine with a private CSR foundation grant (e.g. Reliance Foundation or Kotak Kanya) which specifically allows supplemental maintenance funding without conflict.'
      });
    }

    // Check multiple Central schemes (e.g. CSSS + AICTE Pragati)
    if (centralSchemes.length > 1) {
      conflicts.push({
        id: 'multiple-central-conflict',
        title: '⚠️ Central Government Dual-Availing Rule',
        schemesInvolved: centralSchemes.map(s => s.title),
        severity: 'medium',
        summary: 'National Scholarship Portal (NSP) cross-verifies student Aadhaar numbers and automatically blocks multiple concurrent Central awards.',
        recommendation: 'Choose the scheme offering the higher scholarship amount and submit only one NSP Central application.'
      });
    }

    return conflicts;
  }

  return {
    init,
    getApplications,
    getApplicationById,
    addApplication,
    updateStatus,
    removeApplication,
    checkPolicyConflicts
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ApplicationTracker;
}
