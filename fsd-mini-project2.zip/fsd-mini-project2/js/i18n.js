/**
 * ScholarQuest - Multilingual Translation Engine
 * 
 * Supports regional language toggling (English, Hindi, Telugu)
 * designed specifically so non-English literate parents from rural
 * and marginalized backgrounds can comprehend scholarship criteria.
 */

const I18nEngine = (() => {
  let currentLanguage = 'en';

  const translations = {
    en: {
      brandTitle: 'GrantGlide: ScholarQuest',
      brandSubtitle: 'Intelligent Multi-Criteria Scholarship Matching & Document Readiness Engine',
      tabMatching: 'Scholarship Feed',
      tabLocker: 'Document Locker',
      tabApplications: 'My Applications',
      tabCalculator: 'Financial Aid Calculator',
      tabWhatsApp: 'WhatsApp Alert Bot',
      profileTitle: 'Student Demographic & Academic Profile',
      profileSubtitle: 'Enter your profile parameters to evaluate multi-criteria eligibility against 30+ Indian schemes',
      demoPresetBtn: '✨ Load Professor Demo Preset (Telangana • BC • ₹1.5L • 8.5 GPA)',
      lblState: 'Domicile State',
      lblCaste: 'Caste Category',
      lblIncome: 'Annual Family Income (₹)',
      lblGender: 'Gender',
      lblDegree: 'Current Degree / Course',
      lblGpa: 'Current GPA / Marks (%)',
      btnEvaluate: 'Evaluate Eligibility & Generate Feed',
      qualifyingHeading: 'Tailored Qualifying Scholarships',
      deadlineUrgent: 'Days Remaining',
      awardLabel: 'Award Amount',
      portalLink: 'Visit Official Portal',
      btnChecklist: 'Document Checklist',
      btnSave: 'Bookmark Scheme',
      btnInspector: 'Scheme Details',
      expAlertHeading: '⚠️ Document Expiration Alert System',
      expAlertNotice: 'Certificates expiring within 30 days must be renewed promptly from your local Tahsildar / Revenue office to prevent application rejection.'
    },
    hi: {
      brandTitle: 'ग्रांटग्लाइड: स्कॉलरक्वेस्ट',
      brandSubtitle: 'वंचित एवं मेधावी छात्रों के लिए बुद्धिमान छात्रवृत्ति मिलान और दस्तावेज़ तत्परता प्रणाली',
      tabMatching: 'योग्य छात्रवृत्तियां',
      tabLocker: 'दस्तावेज़ लॉकर',
      tabApplications: 'मेरे आवेदन',
      tabCalculator: 'वित्तीय सहायता कैलकुलेटर',
      tabWhatsApp: 'व्हाट्सएप अलर्ट',
      profileTitle: 'छात्र जनसांख्यिकीय एवं शैक्षणिक विवरण',
      profileSubtitle: '30 से अधिक राष्ट्रीय व राज्य छात्रवृत्ति योजनाओं में अपनी पात्रता परखें',
      demoPresetBtn: '✨ डेमो प्रोफाइल लोड करें (तेलंगाना • पिछड़ा वर्ग • ₹1.5 लाख • 8.5 GPA)',
      lblState: 'मूल निवास राज्य',
      lblCaste: 'सामाजिक श्रेणी (जाति)',
      lblIncome: 'पारिवारिक वार्षिक आय (₹)',
      lblGender: 'लिंग',
      lblDegree: 'वर्तमान डिग्री / पाठ्यक्रम',
      lblGpa: 'वर्तमान जीपीए / प्रतिशत',
      btnEvaluate: 'पात्रता की जांच करें और सूची देखें',
      qualifyingHeading: 'आपके लिए चयनित छात्रवृत्ति योजनाएं',
      deadlineUrgent: 'दिन शेष',
      awardLabel: 'छात्रवृत्ति राशि',
      portalLink: 'आधिकारिक पोर्टल लिंक',
      btnChecklist: 'दस्तावेज़ सूची',
      btnSave: 'सुरक्षित रखें',
      btnInspector: 'विस्तृत विवरण',
      expAlertHeading: '⚠️ दस्तावेज़ नवीनीकरण पूर्व-चेतावनी',
      expAlertNotice: '30 दिनों के भीतर समाप्त होने वाले प्रमाण पत्रों को अपने स्थानीय तहसील कार्यालय / ई-डिस्ट्रिक्ट से तत्काल नवीनीकृत कराएं।'
    },
    te: {
      brandTitle: 'గ్రాంట్‌గ్లైడ్: స్కాలర్‌క్వెస్ట్',
      brandSubtitle: 'విద్యార్థుల కోసం బహుళ-ప్రమాణాల ఆధారిత స్కాలర్‌షిప్ మ్యాచింగ్ మరియు పత్రాల సంసిద్ధత వేదిక',
      tabMatching: 'అర్హతగల స్కాలర్‌షిప్‌లు',
      tabLocker: 'డాక్యుమెంట్ లాకర్',
      tabApplications: 'నా దరఖాస్తులు',
      tabCalculator: 'ఆర్థిక సహాయ కాలిక్యులేటర్',
      tabWhatsApp: 'వాట్సాప్ అలర్ట్ సిమ్యులేటర్',
      profileTitle: 'విద్యార్థి వివరాలు & విద్యార్హత',
      profileSubtitle: '30+ జాతీయ మరియు రాష్ట్ర స్థాయి స్కాలర్‌షిప్ నిబంధనల ప్రకారం మీ అర్హతను తనిఖీ చేయండి',
      demoPresetBtn: '✨ డెమో ప్రొఫైల్ లోడ్ చేయండి (తెలంగాణ • బీసీ • ₹1.5 లక్షల ఆదాయం • 8.5 GPA)',
      lblState: 'స్థానిక రాష్ట్రం (డొమిసైల్)',
      lblCaste: 'కుల వర్గం (కేటగిరీ)',
      lblIncome: 'కుటుంబ వార్షిక ఆదాయం (₹)',
      lblGender: 'లింగం',
      lblDegree: 'ప్రస్తుత డిగ్రీ / కోర్సు',
      lblGpa: 'ప్రస్తుత GPA / శాతం',
      btnEvaluate: 'అర్హతను సరిచూసి జాబితాను రూపొందించు',
      qualifyingHeading: 'మీకు అర్హత ఉన్న స్కాలర్‌షిప్ పథకాలు',
      deadlineUrgent: 'రోజులు మిగిలి ఉన్నాయి',
      awardLabel: 'ఆర్థిక సహాయం మొత్తం',
      portalLink: 'అధికారిక వెబ్‌సైట్ లింక్',
      btnChecklist: 'పత్రాల చెక్‌లిస్ట్',
      btnSave: 'బుక్‌మార్క్ చేయండి',
      btnInspector: 'పూర్తి వివరాలు',
      expAlertHeading: '⚠️ ధృవీకరణ పత్రాల గడువు హెచ్చరిక',
      expAlertNotice: '30 రోజుల్లో గడువు ముగిసే ఆదాయ ధృవీకరణ పత్రాలను మీ సమీప మీసేవా / తహసీల్దార్ కార్యాలయంలో వెంటనే రెన్యూవల్ చేసుకోండి.'
    }
  };

  function setLanguage(lang) {
    if (translations[lang]) {
      currentLanguage = lang;
      applyTranslations();
    }
  }

  function getLanguage() {
    return currentLanguage;
  }

  function t(key) {
    const langObj = translations[currentLanguage] || translations.en;
    return langObj[key] || translations.en[key] || key;
  }

  /**
   * Translates scholarship title and summary if available
   */
  function getSchemeTranslation(scheme) {
    if (currentLanguage !== 'en' && scheme.translations && scheme.translations[currentLanguage]) {
      return {
        title: scheme.translations[currentLanguage].title || scheme.title,
        summary: scheme.translations[currentLanguage].summary || scheme.awardDetails
      };
    }
    return {
      title: scheme.title,
      summary: scheme.awardDetails
    };
  }

  function applyTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      const text = t(key);
      if (text) {
        if (el.tagName === 'INPUT' && el.type === 'button') {
          el.value = text;
        } else {
          el.textContent = text;
        }
      }
    });

    // Fire event for UI refresh
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang: currentLanguage } }));
  }

  return {
    setLanguage,
    getLanguage,
    t,
    getSchemeTranslation,
    applyTranslations
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = I18nEngine;
}
