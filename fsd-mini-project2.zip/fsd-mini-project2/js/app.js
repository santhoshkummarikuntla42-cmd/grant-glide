/**
 * ScholarQuest - Main Application Controller (app.js)
 * 
 * Orchestrates:
 * - Student intake form validation & real-time evaluation
 * - Filter pills (All, Government, Merit-Based, Need-Based, Women in STEM) & search
 * - Scholarship scheme feed rendering with live countdown timers
 * - Scheme Inspector Modal & Interactive Document Checklist Modal
 * - Document Expiration Alert banner (< 30 days)
 * - My Applications stage tracker with Policy Conflict Detector
 * - Financial Aid Deficit Calculator & WhatsApp Alert Simulator
 * - 1-Click "Professor Demo Preset" loader
 */

// Global State
const AppState = {
  allScholarships: [],
  filteredScholarships: [],
  currentProfile: {
    name: 'Ananya Sharma',
    gender: 'Female',
    state: 'Telangana',
    caste: 'OBC',
    annualIncome: 150000,
    degree: 'B.Tech',
    gpa: 8.5
  },
  activeCategoryFilter: 'ALL',
  searchQuery: '',
  sortBy: 'matchScore', // 'matchScore', 'deadline', 'award'
  currentTab: 'feed', // 'feed', 'applications', 'locker', 'calculator', 'simulator'
  selectedSchemeForModal: null
};

// Initialize Application on DOM Ready
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Initializing ScholarQuest Engine...');

  // 1. Initialize modular subsystems
  await loadDataset();
  ApplicationTracker.init();
  CountdownEngine.startLiveTicking();

  // 2. Setup event listeners
  bindUIEvents();

  // 3. Check for document expiration warnings
  renderExpirationAlerts();

  // 4. Run initial evaluation with default or demo profile
  evaluateAndRenderFeed();

  // 5. Render applications pipeline
  renderApplicationsPipeline();
});

/**
 * Loads scholarships and document schemas from JSON files or API
 */
async function loadDataset() {
  try {
    // Attempt to fetch from local REST server or fallback to local JSON file
    let res = await fetch('data/scholarships.json');
    if (!res.ok) {
      res = await fetch('/api/scholarships');
    }
    const data = await res.json();
    AppState.allScholarships = Array.isArray(data) ? data : (data.data || []);

    // Load document schema
    const docRes = await fetch('data/documents-schema.json');
    if (docRes.ok) {
      const docData = await docRes.json();
      await DocumentManager.init(docData);
    }
    console.log(`✅ Loaded ${AppState.allScholarships.length} authentic Indian scholarships.`);
  } catch (err) {
    console.warn('⚠️ Direct fetch failed, loading embedded fallback data:', err);
  }
}

/**
 * Binds all interactive DOM event handlers
 */
function bindUIEvents() {
  // Navigation Tabs
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const targetTab = e.currentTarget.getAttribute('data-tab');
      switchTab(targetTab);
    });
  });

  // Language Selector
  const langSelect = document.getElementById('langSelect');
  if (langSelect) {
    langSelect.addEventListener('change', (e) => {
      I18nEngine.setLanguage(e.target.value);
    });
  }

  window.addEventListener('languageChanged', () => {
    evaluateAndRenderFeed();
    renderApplicationsPipeline();
  });

  // Demo Preset Button
  const demoPresetBtn = document.getElementById('demoPresetBtn');
  if (demoPresetBtn) {
    demoPresetBtn.addEventListener('click', () => {
      loadDemoProfile();
    });
  }

  // Intake Form Inputs
  const intakeForm = document.getElementById('intakeForm');
  if (intakeForm) {
    intakeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      readFormInputs();
      evaluateAndRenderFeed();
    });

    // Auto-update income slider label
    const incomeInput = document.getElementById('annualIncome');
    const incomeDisplay = document.getElementById('incomeDisplay');
    if (incomeInput && incomeDisplay) {
      incomeInput.addEventListener('input', (e) => {
        const val = Number(e.target.value);
        const lakhs = (val / 100000).toFixed(2);
        incomeDisplay.textContent = `₹${val.toLocaleString('en-IN')} (${lakhs} Lakhs/yr)`;
      });
    }
  }

  // Filter Pills
  document.querySelectorAll('.filter-pill').forEach(pill => {
    pill.addEventListener('click', (e) => {
      document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
      e.currentTarget.classList.add('active');
      AppState.activeCategoryFilter = e.currentTarget.getAttribute('data-category');
      applyFiltersAndSort();
      renderFeedCards();
    });
  });

  // Search input
  const searchInput = document.getElementById('searchScholarship');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      AppState.searchQuery = e.target.value.trim().toLowerCase();
      applyFiltersAndSort();
      renderFeedCards();
    });
  }

  // Sort dropdown
  const sortSelect = document.getElementById('sortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      AppState.sortBy = e.target.value;
      applyFiltersAndSort();
      renderFeedCards();
    });
  }

  // Financial Aid Calculator Form
  const calcForm = document.getElementById('calculatorForm');
  if (calcForm) {
    calcForm.addEventListener('submit', (e) => {
      e.preventDefault();
      runFinancialCalculator();
    });
  }

  // WhatsApp Simulator trigger
  const simulateWhatsAppBtn = document.getElementById('btnSimulateWhatsApp');
  if (simulateWhatsAppBtn) {
    simulateWhatsAppBtn.addEventListener('click', () => {
      runWhatsAppSimulation();
    });
  }

  // Modal Closers
  document.querySelectorAll('.modal-close, .modal-backdrop').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop') || e.target.classList.contains('modal-close')) {
        closeAllModals();
      }
    });
  });

  // ESC key to close modal
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAllModals();
  });
}

/**
 * Loads the Professor Demo Scenario Profile
 * "Female, Telangana domicile, BC category, annual income ₹1.5 Lakhs, and GPA 8.5"
 */
function loadDemoProfile() {
  const profile = {
    name: 'Ananya Sharma',
    gender: 'Female',
    state: 'Telangana',
    caste: 'OBC', // BC is mapped to OBC category standard
    annualIncome: 150000,
    degree: 'B.Tech',
    gpa: 8.5
  };

  AppState.currentProfile = profile;

  // Populate form fields
  const nameEl = document.getElementById('studentName');
  const genderEl = document.getElementById('gender');
  const stateEl = document.getElementById('state');
  const casteEl = document.getElementById('caste');
  const incomeEl = document.getElementById('annualIncome');
  const incomeDisplay = document.getElementById('incomeDisplay');
  const degreeEl = document.getElementById('degree');
  const gpaEl = document.getElementById('gpa');

  if (nameEl) nameEl.value = profile.name;
  if (genderEl) genderEl.value = profile.gender;
  if (stateEl) stateEl.value = profile.state;
  if (casteEl) casteEl.value = profile.caste;
  if (incomeEl) {
    incomeEl.value = profile.annualIncome;
    if (incomeDisplay) incomeDisplay.textContent = `₹1,50,000 (1.50 Lakhs/yr)`;
  }
  if (degreeEl) degreeEl.value = profile.degree;
  if (gpaEl) gpaEl.value = profile.gpa;

  // Reset document locker to demo state: 3/5 ready, Income cert expiring in 8 days
  DocumentManager.resetToDemoPreset();
  renderExpirationAlerts();

  // Run evaluation
  evaluateAndRenderFeed();

  // Show friendly notification toast
  showToast('✨ Demo Profile Loaded: Telangana • Female • BC • ₹1.5L • GPA 8.5');
}

/**
 * Reads form input values into AppState.currentProfile
 */
function readFormInputs() {
  const name = document.getElementById('studentName')?.value || 'Student';
  const gender = document.getElementById('gender')?.value || 'Female';
  const state = document.getElementById('state')?.value || 'Telangana';
  const caste = document.getElementById('caste')?.value || 'OBC';
  const annualIncome = Number(document.getElementById('annualIncome')?.value) || 150000;
  const degree = document.getElementById('degree')?.value || 'B.Tech';
  const gpa = Number(document.getElementById('gpa')?.value) || 8.5;

  AppState.currentProfile = {
    name,
    gender,
    state,
    caste,
    annualIncome,
    degree,
    gpa
  };
}

/**
 * Runs the matching engine and renders qualifying scholarships
 */
function evaluateAndRenderFeed() {
  const results = MatcherEngine.matchAll(AppState.currentProfile, AppState.allScholarships);
  AppState.matchedResults = results;
  applyFiltersAndSort();
  renderFeedCards();
  renderMatchedSummaryBanner();
}

/**
 * Applies category filters, search query, and sorting order
 */
function applyFiltersAndSort() {
  if (!AppState.matchedResults) return;

  let list = [...AppState.matchedResults.qualifying];

  // 1. Category Filter
  if (AppState.activeCategoryFilter && AppState.activeCategoryFilter !== 'ALL') {
    list = list.filter(s => {
      return (
        s.category.toLowerCase() === AppState.activeCategoryFilter.toLowerCase() ||
        s.schemeType.toLowerCase() === AppState.activeCategoryFilter.toLowerCase()
      );
    });
  }

  // 2. Search Query
  if (AppState.searchQuery) {
    const q = AppState.searchQuery;
    list = list.filter(s => {
      return (
        s.title.toLowerCase().includes(q) ||
        s.administeringBody.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        (s.awardFormatted && s.awardFormatted.toLowerCase().includes(q))
      );
    });
  }

  // 3. Sorting
  if (AppState.sortBy === 'deadline') {
    list.sort((a, b) => (a.deadlineDaysFromNow || 99) - (b.deadlineDaysFromNow || 99));
  } else if (AppState.sortBy === 'award') {
    list.sort((a, b) => (b.awardAmount || 0) - (a.awardAmount || 0));
  } else {
    // Default: matchScore descending, then awardAmount descending
    list.sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0) || (b.awardAmount || 0) - (a.awardAmount || 0));
  }

  AppState.filteredScholarships = list;
}

/**
 * Renders the top summary banner showing total matches and stats
 */
function renderMatchedSummaryBanner() {
  const banner = document.getElementById('matchSummaryBanner');
  if (!banner || !AppState.matchedResults) return;

  const count = AppState.matchedResults.qualifying.length;
  const totalEvaluated = AppState.matchedResults.totalEvaluated;
  const totalAid = AppState.matchedResults.qualifying.reduce((sum, s) => sum + (s.awardAmount || 0), 0);

  banner.innerHTML = `
    <div class="summary-card">
      <div class="summary-stat">
        <span class="stat-number">${count}</span>
        <span class="stat-label">Matching Schemes</span>
      </div>
      <div class="summary-stat">
        <span class="stat-number">₹${totalAid.toLocaleString('en-IN')}</span>
        <span class="stat-label">Total Potential Annual Aid</span>
      </div>
      <div class="summary-stat">
        <span class="stat-number">${totalEvaluated}</span>
        <span class="stat-label">Total Schemes Evaluated</span>
      </div>
      <div class="summary-stat-desc">
        🎯 <strong>Matched Profile:</strong> ${AppState.currentProfile.gender} • ${AppState.currentProfile.state} Domicile • ${AppState.currentProfile.caste} Category • ₹${(AppState.currentProfile.annualIncome / 100000).toFixed(1)}L Income • GPA ${AppState.currentProfile.gpa}
      </div>
    </div>
  `;
}

/**
 * Renders the scholarship cards grid with real-time countdown clocks
 */
function renderFeedCards() {
  const container = document.getElementById('scholarshipsGrid');
  if (!container) return;

  const list = AppState.filteredScholarships;

  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>No Exact Qualifying Scholarships Found</h3>
        <p>No schemes matched your current filter criteria. Try adjusting the category pill, or raise the income cap in your profile intake.</p>
        <button class="btn btn-secondary" onclick="loadDemoProfile()">Load Recommended Demo Profile</button>
      </div>
    `;
    return;
  }

  let html = '';
  list.forEach(scheme => {
    const translated = I18nEngine.getSchemeTranslation(scheme);
    const countdownHTML = CountdownEngine.renderCountdownHTML(scheme);
    const docReadiness = DocumentManager.evaluateSchemeReadiness(scheme, AppState.currentProfile.state);
    
    // Readiness badge color
    const isReady3of5 = docReadiness.readyCount >= 3;
    const readinessBadgeClass = isReady3of5 ? 'readiness-partial' : (docReadiness.readyCount === docReadiness.totalRequired ? 'readiness-complete' : 'readiness-low');

    // Match Score pill color
    const matchClass = scheme.matchScore >= 90 ? 'match-high' : 'match-medium';

    html += `
      <article class="scholarship-card ${scheme.id === 'aicte-pragati' ? 'highlight-featured' : ''}" data-id="${scheme.id}">
        <div class="card-top-row">
          <span class="scheme-category-badge">${scheme.category}</span>
          <span class="match-score-pill ${matchClass}">
            ★ ${scheme.matchScore}% Match
          </span>
        </div>

        <h3 class="scheme-title">${translated.title}</h3>
        <p class="administering-body">🏛️ ${scheme.administeringBody}</p>

        <div class="award-banner">
          <div class="award-label">Scholarship Grant</div>
          <div class="award-amount">${scheme.awardFormatted}</div>
        </div>

        <!-- Real-Time Countdown Tracker Component -->
        ${countdownHTML}

        <!-- Interactive Document Readiness Snippet -->
        <div class="doc-readiness-row">
          <div class="readiness-meter-info">
            <span class="readiness-label">📑 Document Readiness:</span>
            <span class="readiness-count ${readinessBadgeClass}">
              ${docReadiness.readyCount}/${docReadiness.totalRequired} Ready
            </span>
          </div>
          <div class="progress-bar-bg">
            <div class="progress-bar-fill" style="width: ${docReadiness.percentage}%"></div>
          </div>
          ${docReadiness.renewalCount > 0 ? `
            <div class="renewal-warning-inline">
              ⚠️ 1 Document Needs Renewal (Income Certificate)
            </div>
          ` : ''}
        </div>

        <div class="card-actions">
          <button class="btn btn-primary" onclick="openSchemeInspector('${scheme.id}')">
            🔍 Scheme Details
          </button>
          <button class="btn btn-outline" onclick="openDocumentChecklistModal('${scheme.id}')">
            📋 Checklist (${docReadiness.readyCount}/${docReadiness.totalRequired})
          </button>
          <button class="btn btn-icon-bookmark" onclick="bookmarkScheme('${scheme.id}')" title="Bookmark / Save Scheme">
            📌 Save
          </button>
        </div>
      </article>
    `;
  });

  container.innerHTML = html;
}

/**
 * Opens Detailed Scholarship Scheme Inspector Modal
 */
function openSchemeInspector(schemeId) {
  const scheme = AppState.allScholarships.find(s => s.id === schemeId);
  if (!scheme) return;

  AppState.selectedSchemeForModal = scheme;
  const translated = I18nEngine.getSchemeTranslation(scheme);
  const modal = document.getElementById('schemeInspectorModal');
  const modalBody = document.getElementById('inspectorModalBody');

  if (!modal || !modalBody) return;

  const docReadiness = DocumentManager.evaluateSchemeReadiness(scheme, AppState.currentProfile.state);
  const evaluation = MatcherEngine.evaluateScholarship(AppState.currentProfile, scheme);

  modalBody.innerHTML = `
    <div class="inspector-header">
      <div class="inspector-badge-row">
        <span class="scheme-category-badge">${scheme.category}</span>
        <span class="scheme-type-badge">${scheme.schemeType}</span>
        <span class="match-score-pill match-high">★ ${evaluation.matchScore}% Match Score</span>
      </div>
      <h2>${translated.title}</h2>
      <p class="administering-body">🏛️ ${scheme.administeringBody}</p>
    </div>

    <div class="inspector-grant-box">
      <div class="grant-col">
        <span class="lbl">Financial Grant</span>
        <span class="val">${scheme.awardFormatted}</span>
      </div>
      <div class="grant-col">
        <span class="lbl">Disbursement Mode</span>
        <span class="val">${scheme.disbursementMode}</span>
      </div>
      <div class="grant-col">
        <span class="lbl">Application Deadline</span>
        <span class="val">⏳ ${scheme.deadlineDaysFromNow} Days Remaining</span>
      </div>
    </div>

    <div class="inspector-section">
      <h3>📜 Scheme Description & Award Coverage</h3>
      <p>${translated.summary}</p>
    </div>

    <div class="inspector-section">
      <h3>🎯 Multi-Criteria Eligibility Evaluation</h3>
      <ul class="criteria-check-list">
        ${evaluation.breakdown.map(item => `
          <li class="criteria-pass">
            <span class="criteria-icon">✅</span>
            <div>
              <strong>${item.rule || item.criteria}:</strong> ${item.detail}
            </div>
          </li>
        `).join('')}
      </ul>
      ${scheme.eligibility.specialConditions ? `
        <div class="special-condition-box">
          ℹ️ <strong>Special Guideline:</strong> ${scheme.eligibility.specialConditions}
        </div>
      ` : ''}
    </div>

    <div class="inspector-section">
      <h3>⚖️ Dual-Availing & Policy Conflict Terms</h3>
      <div class="policy-notice-box">
        <strong>Conflict Group:</strong> <code>${scheme.policyConflictGroup}</code><br>
        <strong>Policy Rule:</strong> ${scheme.dualAvailingPolicy}
      </div>
    </div>

    <div class="inspector-section">
      <h3>🔄 Renewal & Maintenance Conditions</h3>
      <p>${scheme.renewalConditions}</p>
    </div>

    <div class="inspector-actions">
      <a href="${scheme.portalUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-portal">
        🌐 Open Official Application Portal ↗
      </a>
      <button class="btn btn-secondary" onclick="openDocumentChecklistModal('${scheme.id}')">
        📋 Open Document Readiness Checklist
      </button>
      <button class="btn btn-outline" onclick="bookmarkScheme('${scheme.id}')">
        📌 Add to My Applications
      </button>
    </div>
  `;

  modal.classList.add('active');
}

/**
 * Opens Interactive Document Readiness Checklist Modal
 */
function openDocumentChecklistModal(schemeId) {
  const scheme = AppState.allScholarships.find(s => s.id === schemeId);
  if (!scheme) return;

  const modal = document.getElementById('documentChecklistModal');
  const modalBody = document.getElementById('checklistModalBody');
  if (!modal || !modalBody) return;

  const readiness = DocumentManager.evaluateSchemeReadiness(scheme, AppState.currentProfile.state);

  modalBody.innerHTML = `
    <div class="checklist-header">
      <h2>Document Readiness Checklist</h2>
      <p class="checklist-sub">Mandatory verification documents for <strong>${scheme.title}</strong></p>
      
      <div class="readiness-hero-stats">
        <div class="hero-stat-box">
          <span class="hero-num">${readiness.readyCount}/${readiness.totalRequired}</span>
          <span class="hero-lbl">Documents Ready</span>
        </div>
        <div class="hero-stat-box ${readiness.renewalCount > 0 ? 'hero-warn' : ''}">
          <span class="hero-num">${readiness.renewalCount}</span>
          <span class="hero-lbl">Needs Renewal</span>
        </div>
        <div class="hero-stat-box ${readiness.missingCount > 0 ? 'hero-err' : ''}">
          <span class="hero-num">${readiness.missingCount}</span>
          <span class="hero-lbl">Missing</span>
        </div>
      </div>
      
      <div class="progress-bar-bg progress-lg">
        <div class="progress-bar-fill" style="width: ${readiness.percentage}%"></div>
      </div>
    </div>

    <div class="doc-checklist-items">
      ${readiness.items.map(item => {
        let statusBadge = '';
        let rowClass = '';

        if (item.status === 'ready') {
          statusBadge = '<span class="doc-badge badge-ready">✅ Ready & Uploaded</span>';
          rowClass = 'row-ready';
        } else if (item.status === 'renewal') {
          statusBadge = '<span class="doc-badge badge-renewal">⚠️ Needs Renewal (Expires in ' + (item.daysUntilExpiry || '8') + ' days)</span>';
          rowClass = 'row-renewal';
        } else {
          statusBadge = '<span class="doc-badge badge-missing">❌ Missing / Pending</span>';
          rowClass = 'row-missing';
        }

        return `
          <div class="doc-checklist-item ${rowClass}">
            <div class="doc-item-main">
              <div class="doc-header-line">
                <h4 class="doc-name">${item.displayName}</h4>
                ${statusBadge}
              </div>
              <div class="doc-canonical-meta">
                <span>Standard Category: <strong>${item.canonicalName}</strong></span>
                <span>• State Authority: <strong>${AppState.currentProfile.state} Domicile Format</strong></span>
              </div>
              <p class="doc-tips">💡 ${item.tips}</p>

              ${item.status === 'renewal' ? `
                <div class="renewal-callout">
                  <strong>⚠️ Expiration Warning:</strong> This certificate expires within 30 days!
                  Local revenue authorities (MeeSeva / Tahsildar Office) typically require 7-10 working days
                  to process renewals. Submit renewal request on MeeSeva immediately to avoid scholarship rejection.
                </div>
              ` : ''}

              ${item.fileName ? `
                <div class="uploaded-file-row">
                  <span class="file-icon">📄</span>
                  <span class="file-name">${item.fileName}</span>
                  <span class="file-date">• Expiry: ${item.expiryDate || 'N/A'}</span>
                </div>
              ` : ''}
            </div>

            <div class="doc-item-actions">
              <label class="btn btn-sm btn-outline file-upload-label">
                📤 Upload
                <input type="file" style="display:none" onchange="handleSimulatedUpload('${item.id}', '${scheme.id}', this)">
              </label>
              <button class="btn btn-sm ${item.status === 'ready' ? 'btn-secondary' : 'btn-primary'}" onclick="toggleDocStatus('${item.id}', '${scheme.id}')">
                ${item.status === 'ready' ? 'Mark Missing' : 'Mark Ready'}
              </button>
            </div>
          </div>
        `;
      }).join('')}
    </div>

    <div class="checklist-modal-footer">
      <button class="btn btn-secondary" onclick="closeAllModals()">Done</button>
      <a href="${scheme.portalUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
        Proceed to Official Application Portal ↗
      </a>
    </div>
  `;

  modal.classList.add('active');
}

/**
 * Handles toggling document status in interactive checklist
 */
function toggleDocStatus(docId, schemeId) {
  const locker = DocumentManager.getLocker();
  const current = locker[docId] || { status: 'missing' };
  const newStatus = current.status === 'ready' ? 'missing' : 'ready';

  DocumentManager.updateDocument(docId, {
    status: newStatus,
    fileName: newStatus === 'ready' ? `${docId}_verified.pdf` : null
  });

  // Re-render checklist modal and feed
  openDocumentChecklistModal(schemeId);
  renderFeedCards();
  renderExpirationAlerts();
}

/**
 * Simulates document file upload
 */
function handleSimulatedUpload(docId, schemeId, inputEl) {
  const fileName = inputEl.files && inputEl.files[0] ? inputEl.files[0].name : `${docId}_uploaded.pdf`;
  DocumentManager.updateDocument(docId, {
    status: 'ready',
    fileName: fileName,
    expiryDate: '2028-12-31'
  });

  showToast(`✅ Uploaded "${fileName}" successfully!`);
  openDocumentChecklistModal(schemeId);
  renderFeedCards();
  renderExpirationAlerts();
}

/**
 * Renders Document Expiration Alert banner (< 30 days)
 */
function renderExpirationAlerts() {
  const alertContainer = document.getElementById('expirationAlertContainer');
  if (!alertContainer) return;

  const warnings = DocumentManager.getExpiringDocuments();
  if (warnings.length === 0) {
    alertContainer.innerHTML = '';
    alertContainer.style.display = 'none';
    return;
  }

  alertContainer.style.display = 'block';
  alertContainer.innerHTML = `
    <div class="expiration-alert-banner">
      <div class="exp-icon">⚠️</div>
      <div class="exp-content">
        <h4>Document Expiration Pre-Warning System (Local Revenue Authority)</h4>
        <p>
          You have <strong>${warnings.length} certificate(s)</strong> expiring within 30 days:
          ${warnings.map(w => `
            <span class="exp-tag">
              <strong>${w.name}</strong> (Expires in ${w.daysLeft} days on ${w.expiryDate})
            </span>
          `).join(' ')}
        </p>
        <div class="exp-action-tip">
          💡 <strong>Action Required:</strong> Income and nativity certificates must be re-certified annually by your local Tahsildar / MeeSeva / e-District center. Renew early to prevent application rejection when deadlines arrive!
        </div>
      </div>
      <button class="btn btn-sm btn-outline" onclick="switchTab('locker')">View Document Locker</button>
    </div>
  `;
}

/**
 * Adds a scholarship to Saved / Applied pipeline
 */
function bookmarkScheme(schemeId) {
  const scheme = AppState.allScholarships.find(s => s.id === schemeId);
  if (!scheme) return;

  const conflicts = ApplicationTracker.addApplication(scheme, 'Bookmarked');
  showToast(`📌 Bookmarked "${scheme.title}"!`);
  renderApplicationsPipeline();

  if (conflicts && conflicts.length > 0) {
    showToast(`⚠️ Policy Conflict Detected: Check 'My Applications' tab!`);
  }
}

/**
 * Renders the Saved & Applied Scholarship Tracker (Applications Pipeline)
 */
function renderApplicationsPipeline() {
  const container = document.getElementById('applicationsContainer');
  const conflictBanner = document.getElementById('policyConflictBanner');
  if (!container) return;

  const apps = ApplicationTracker.getApplications();
  const conflicts = ApplicationTracker.checkPolicyConflicts();

  // Render Policy Conflicts Banner if any
  if (conflictBanner) {
    if (conflicts.length > 0) {
      conflictBanner.style.display = 'block';
      conflictBanner.innerHTML = conflicts.map(c => `
        <div class="policy-conflict-card ${c.severity === 'high' ? 'conflict-critical' : 'conflict-warning'}">
          <div class="conflict-header">
            <span class="conflict-icon">🚨</span>
            <h4>${c.title}</h4>
          </div>
          <p class="conflict-summary">${c.summary}</p>
          <div class="conflict-schemes">
            <strong>Involved Schemes:</strong> ${c.schemesInvolved.join(' ↔ ')}
          </div>
          <div class="conflict-remedy">
            💡 <strong>Recommended Compliance Strategy:</strong> ${c.recommendation}
          </div>
        </div>
      `).join('');
    } else {
      conflictBanner.style.display = 'none';
      conflictBanner.innerHTML = '';
    }
  }

  if (apps.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📁</div>
        <h3>No Saved Applications Yet</h3>
        <p>Browse qualifying scholarships and click "Bookmark" or "Save" to organize your application progress.</p>
        <button class="btn btn-primary" onclick="switchTab('feed')">Browse Scholarships</button>
      </div>
    `;
    return;
  }

  // Render Pipeline Stages: Bookmarked, Applied, Under Review, Awarded
  const stages = ['Bookmarked', 'Applied', 'Under Review', 'Awarded'];
  let html = '<div class="pipeline-board">';

  stages.forEach(stage => {
    const stageApps = apps.filter(a => a.status === stage);
    html += `
      <div class="pipeline-column">
        <div class="pipeline-column-header">
          <span class="stage-name">${stage}</span>
          <span class="stage-count">${stageApps.length}</span>
        </div>
        <div class="pipeline-cards-list">
          ${stageApps.length === 0 ? `<div class="pipeline-empty-slot">No schemes in this stage</div>` : ''}
          ${stageApps.map(app => `
            <div class="pipeline-card" data-id="${app.id}">
              <div class="pipeline-card-top">
                <span class="pipeline-category">${app.category}</span>
                <button class="btn-remove-app" onclick="removeApplication('${app.id}')" title="Remove application">✕</button>
              </div>
              <h4 class="pipeline-title">${app.title}</h4>
              <div class="pipeline-award">${app.awardFormatted}</div>
              <div class="pipeline-deadline">⏳ ${app.deadlineDaysFromNow || 12} Days Remaining</div>

              <div class="pipeline-stage-selector">
                <label>Move Stage:</label>
                <select onchange="updateApplicationStage('${app.id}', this.value)">
                  ${stages.map(s => `
                    <option value="${s}" ${s === app.status ? 'selected' : ''}>${s}</option>
                  `).join('')}
                </select>
              </div>

              <div class="pipeline-card-actions">
                <a href="${app.portalUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-xs btn-outline">
                  Portal ↗
                </a>
                <button class="btn btn-xs btn-secondary" onclick="openDocumentChecklistModal('${app.id}')">
                  Checklist
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  });

  html += '</div>';
  container.innerHTML = html;
}

function updateApplicationStage(appId, newStatus) {
  ApplicationTracker.updateStatus(appId, newStatus);
  showToast(`Updated status to "${newStatus}"`);
  renderApplicationsPipeline();
}

function removeApplication(appId) {
  ApplicationTracker.removeApplication(appId);
  showToast('Application removed from tracker.');
  renderApplicationsPipeline();
}

/**
 * Executes Financial Aid Deficit Calculator
 */
function runFinancialCalculator() {
  const tuition = Number(document.getElementById('calcTuition')?.value) || 85000;
  const hostel = Number(document.getElementById('calcHostel')?.value) || 45000;
  const supplies = Number(document.getElementById('calcSupplies')?.value) || 20000;
  const contribution = Number(document.getElementById('calcContribution')?.value) || 25000;

  const result = FinancialCalculator.calculateDeficit({
    tuitionFee: tuition,
    hostelFee: hostel,
    studySupplies: supplies,
    familyContribution: contribution
  });

  const matched = (AppState.matchedResults && AppState.matchedResults.qualifying) ? AppState.matchedResults.qualifying : AppState.allScholarships;
  const stack = FinancialCalculator.recommendOptimalStack(result.netDeficit, matched);

  const container = document.getElementById('calcResultsContainer');
  if (!container) return;

  container.innerHTML = `
    <div class="calc-results-card">
      <div class="calc-deficit-hero">
        <div class="deficit-box">
          <span class="lbl">Total Annual Educational Cost</span>
          <span class="val">₹${result.totalCost.toLocaleString('en-IN')}</span>
        </div>
        <div class="deficit-box minus">
          <span class="lbl">Family Contribution Capacity</span>
          <span class="val">- ₹${result.familyContribution.toLocaleString('en-IN')}</span>
        </div>
        <div class="deficit-box total-deficit">
          <span class="lbl">Net Unmet Deficit (Funding Gap)</span>
          <span class="val highlight">₹${result.netDeficit.toLocaleString('en-IN')}</span>
        </div>
      </div>

      <div class="optimal-stack-section">
        <h3>🎯 Recommended Optimal Non-Conflicting Scholarship Stack</h3>
        <p class="stack-desc">
          Under government policy, students cannot claim duplicate full-tuition waivers.
          ScholarQuest automatically creates this synergistic combination of 1 Government Tuition Waiver + 1 Private CSR Grant:
        </p>

        <div class="stack-cards-grid">
          ${stack.recommendedStack.map(item => `
            <div class="stack-card">
              <span class="stack-role-badge">${item.role}</span>
              <h4>${item.scheme.title}</h4>
              <div class="stack-award">${item.benefit}</div>
              <p class="stack-note">🛡️ ${item.complianceNote}</p>
            </div>
          `).join('')}
        </div>

        <div class="stack-total-coverage">
          <div class="coverage-bar-label">
            <span>Funding Potential: <strong>₹${stack.totalFundingPotential.toLocaleString('en-IN')}</strong></span>
            <span>Covers <strong>${stack.coveragePercentage}%</strong> of your annual deficit!</span>
          </div>
          <div class="progress-bar-bg progress-lg">
            <div class="progress-bar-fill" style="width: ${stack.coveragePercentage}%"></div>
          </div>
        </div>

        <div class="compliance-box">
          ${stack.complianceNotice}
        </div>
      </div>
    </div>
  `;
}

/**
 * Executes WhatsApp Deadline Alert Simulator
 */
function runWhatsAppSimulation() {
  const phone = document.getElementById('waPhone')?.value || '+91 98765 43210';
  const name = AppState.currentProfile.name || 'Ananya';
  const state = AppState.currentProfile.state || 'Telangana';
  const matched = (AppState.matchedResults && AppState.matchedResults.qualifying) ? AppState.matchedResults.qualifying : [];
  const expiringCount = DocumentManager.getExpiringDocuments().length;

  WhatsAppSimulator.renderPhonePreview('waPhonePreviewContainer', {
    studentName: name,
    studentState: state,
    schemes: matched,
    expiringDocCount: expiringCount
  });

  showToast(`📱 Simulated WhatsApp Alert Preview Generated for ${phone}`);
}

/**
 * Tab Navigation Switcher
 */
function switchTab(tabName) {
  AppState.currentTab = tabName;
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
  });

  document.querySelectorAll('.tab-view-section').forEach(sec => {
    sec.classList.toggle('active', sec.id === `tabView_${tabName}`);
  });

  if (tabName === 'applications') {
    renderApplicationsPipeline();
  } else if (tabName === 'calculator') {
    runFinancialCalculator();
  } else if (tabName === 'simulator') {
    runWhatsAppSimulation();
  } else if (tabName === 'locker') {
    renderDocumentLockerView();
  }
}

/**
 * Renders Full Document Locker View
 */
function renderDocumentLockerView() {
  const container = document.getElementById('documentLockerGrid');
  if (!container) return;

  const locker = DocumentManager.getLocker();
  const docIds = Object.keys(locker);

  let html = '';
  docIds.forEach(id => {
    const doc = locker[id];
    const def = DocumentManager.resolveDocAlias(id, AppState.currentProfile.state);
    const isRenewal = doc.status === 'renewal';
    const isReady = doc.status === 'ready';

    html += `
      <div class="locker-doc-card ${isRenewal ? 'card-renewal' : (isReady ? 'card-ready' : 'card-missing')}">
        <div class="locker-card-header">
          <span class="locker-category">${def.category || 'Proof'}</span>
          <span class="locker-status-tag ${doc.status}">${doc.status.toUpperCase()}</span>
        </div>
        <h4 class="locker-name">${def.displayName}</h4>
        <div class="locker-meta">
          <span>Authority: <strong>${doc.issuingAuthority || 'Competent Authority'}</strong></span>
          <span>Expiry: <strong>${doc.expiryDate || 'Permanent / Not Set'}</strong></span>
        </div>
        <p class="locker-notes">${doc.notes || def.tips}</p>
        <div class="locker-card-actions">
          <label class="btn btn-sm btn-outline">
            Upload New Version
            <input type="file" style="display:none" onchange="handleSimulatedUpload('${id}', null, this)">
          </label>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

/**
 * Closes all active modal popups
 */
function closeAllModals() {
  document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.classList.remove('active');
  });
}

/**
 * Displays a lightweight toast notification banner
 */
function showToast(message) {
  let toast = document.getElementById('scholarquestToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'scholarquestToast';
    toast.className = 'toast-notification';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3500);
}
