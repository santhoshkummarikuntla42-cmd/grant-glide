/**
 * ScholarQuest - Data Store Layer
 * 
 * Manages loading and caching of scholarship schemas, canonical documents,
 * and user application records with JSON file persistence.
 */

const fs = require('fs');
const path = require('path');

const SCHOLARSHIPS_FILE = path.join(__dirname, '..', 'data', 'scholarships.json');
const DOCUMENTS_FILE = path.join(__dirname, '..', 'data', 'documents-schema.json');
const APPLICATIONS_STORE_FILE = path.join(__dirname, '..', 'data', 'user_applications.json');

// In-memory cache for fast lookups
let cachedScholarships = null;
let cachedDocuments = null;

/**
 * Loads all scholarships from the dataset.
 */
function getAllScholarships() {
  if (!cachedScholarships) {
    try {
      const rawData = fs.readFileSync(SCHOLARSHIPS_FILE, 'utf8');
      cachedScholarships = JSON.parse(rawData);
    } catch (err) {
      console.error('Error loading scholarships file:', err.message);
      cachedScholarships = [];
    }
  }
  return cachedScholarships;
}

/**
 * Loads canonical document definitions and state aliases.
 */
function getAllDocuments() {
  if (!cachedDocuments) {
    try {
      const rawData = fs.readFileSync(DOCUMENTS_FILE, 'utf8');
      cachedDocuments = JSON.parse(rawData);
    } catch (err) {
      console.error('Error loading documents file:', err.message);
      cachedDocuments = { canonicalDocuments: [] };
    }
  }
  return cachedDocuments;
}

/**
 * Reads user saved applications from disk.
 */
function getUserApplications() {
  try {
    if (fs.existsSync(APPLICATIONS_STORE_FILE)) {
      const data = fs.readFileSync(APPLICATIONS_STORE_FILE, 'utf8');
      return JSON.parse(data);
    }
  } catch (err) {
    console.error('Error reading user applications:', err.message);
  }
  return [];
}

/**
 * Persists user saved applications to disk.
 */
function saveUserApplications(applications) {
  try {
    fs.writeFileSync(APPLICATIONS_STORE_FILE, JSON.stringify(applications, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('Error writing user applications:', err.message);
    return false;
  }
}

module.exports = {
  getAllScholarships,
  getAllDocuments,
  getUserApplications,
  saveUserApplications
};
