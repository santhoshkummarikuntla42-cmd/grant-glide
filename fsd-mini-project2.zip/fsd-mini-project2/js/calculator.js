/**
 * ScholarQuest - Financial Aid Deficit Calculator & Scholarship Stacker
 * 
 * Computes:
 * 1. Total Annual Cost of Education (Tuition + Living + Supplies)
 * 2. Unmet Student Financial Deficit (Cost - Family Capacity)
 * 3. Optimal Non-Conflicting Scholarship Combination (e.g., State Fee Reimbursement + Private CSR Grant)
 */

const FinancialCalculator = (() => {

  /**
   * Computes educational cost deficit.
   */
  function calculateDeficit({ tuitionFee, hostelFee, studySupplies, familyContribution }) {
    const tuition = Number(tuitionFee) || 0;
    const hostel = Number(hostelFee) || 0;
    const supplies = Number(studySupplies) || 0;
    const contribution = Number(familyContribution) || 0;

    const totalCost = tuition + hostel + supplies;
    const netDeficit = Math.max(0, totalCost - contribution);

    return {
      tuition,
      hostel,
      supplies,
      totalCost,
      familyContribution: contribution,
      netDeficit
    };
  }

  /**
   * Recommends a synergistic, legally permissible scholarship stack.
   * Pair 1 Government Scheme (Tuition fee waiver) + 1 Private CSR Grant (Living/maintenance).
   * @param {number} netDeficit 
   * @param {Array} matchedSchemes 
   */
  function recommendOptimalStack(netDeficit, matchedSchemes = []) {
    // Separate into Government and Private
    const govtSchemes = matchedSchemes.filter(s => s.isGovernment || s.schemeType.includes('Government'));
    const privateSchemes = matchedSchemes.filter(s => !s.isGovernment && !s.schemeType.includes('Government'));

    // Pick top government scheme
    const primaryGovt = govtSchemes.length > 0 ? govtSchemes[0] : null;

    // Pick top private scheme
    const supplementalPrivate = privateSchemes.length > 0 ? privateSchemes[0] : null;

    const recommendedStack = [];
    let totalFundingPotential = 0;

    if (primaryGovt) {
      recommendedStack.push({
        scheme: primaryGovt,
        role: 'Primary Tuition Coverage',
        benefit: primaryGovt.awardFormatted,
        complianceNote: 'Sanctioned for academic tuition and institute fee reimbursement.'
      });
      totalFundingPotential += primaryGovt.awardAmount;
    }

    if (supplementalPrivate) {
      recommendedStack.push({
        scheme: supplementalPrivate,
        role: 'Supplemental Living & Tech Allowance',
        benefit: supplementalPrivate.awardFormatted,
        complianceNote: 'Permissible private CSR aid to bridge remaining hostel, laptop, and living expenses.'
      });
      totalFundingPotential += supplementalPrivate.awardAmount;
    }

    const coveragePercentage = netDeficit > 0 
      ? Math.min(100, Math.round((totalFundingPotential / netDeficit) * 100))
      : 100;

    return {
      netDeficit,
      totalFundingPotential,
      coveragePercentage,
      recommendedStack,
      complianceNotice: '✅ Compliant with UGC & State Dual-Availing Guidelines: Combining 1 Institutional Fee Waiver + 1 Private CSR Maintenance Fellowship is legally permissible and maximizes student financial security.'
    };
  }

  return {
    calculateDeficit,
    recommendOptimalStack
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FinancialCalculator;
}
