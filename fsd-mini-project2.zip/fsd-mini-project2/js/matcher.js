/**
 * ScholarQuest - Multi-Criteria Matching Algorithm Engine
 * 
 * Evaluates student demographic and academic profiles against scholarship predicate rules:
 * - Income ceiling (annual family income <= maxIncome)
 * - Social caste reservation (caste in allowedCastes or Open/All)
 * - State of domicile (state in allowedStates or All-India)
 * - Gender requirements (strictly enforced for women-only schemes)
 * - Academic level / degree enrolled
 * - Academic merit threshold (GPA / marks percentage)
 * 
 * Computes transparent match score (0 - 100%) and itemized breakdown of passing/failing criteria.
 */

const MatcherEngine = (() => {

  /**
   * Evaluates a single scholarship against the user profile.
   * @param {Object} profile - Student's demographic and academic profile
   * @param {Object} scheme - Scholarship record with eligibility predicate rules
   * @returns {Object} { isMatch, matchScore, breakdown, disqualifications }
   */
  function evaluateScholarship(profile, scheme) {
    const rules = scheme.eligibility;
    const disqualifications = [];
    const breakdown = [];
    let score = 0;

    // 1. Gender Validation
    const genderMatches = rules.genders.includes('ALL') || 
                          rules.genders.includes('Any') || 
                          rules.genders.includes(profile.gender);
    if (!genderMatches) {
      disqualifications.push({
        rule: 'Gender Requirement',
        message: `Exclusively for ${rules.genders.join(' / ')} candidates. Candidate is ${profile.gender}.`
      });
    } else {
      breakdown.push({
        rule: 'Gender Requirement',
        passed: true,
        detail: `Qualifies under ${profile.gender} criteria`
      });
    }

    // 2. Annual Household Income Cap
    const studentIncome = Number(profile.annualIncome) || 0;
    const incomePassed = studentIncome <= rules.maxIncome;
    if (!incomePassed) {
      const diff = studentIncome - rules.maxIncome;
      disqualifications.push({
        rule: 'Family Income Ceiling',
        message: `Family income of ₹${studentIncome.toLocaleString('en-IN')} exceeds limit of ₹${rules.maxIncome.toLocaleString('en-IN')} by ₹${diff.toLocaleString('en-IN')}.`
      });
    } else {
      score += 25;
      breakdown.push({
        rule: 'Family Income Ceiling',
        passed: true,
        detail: `₹${studentIncome.toLocaleString('en-IN')} is within ceiling of ₹${rules.maxIncome.toLocaleString('en-IN')}`
      });
    }

    // 3. Social Category / Caste Reservation
    // Note: If scheme specifies 'General', all candidates qualify for Open Category.
    // If scheme is caste-restricted (e.g. SC/ST/OBC), profile must match.
    const castePassed = rules.castes.includes('ALL') || 
                        rules.castes.includes(profile.caste) ||
                        (rules.castes.includes('General') && profile.caste === 'General');
                        
    if (!castePassed) {
      disqualifications.push({
        rule: 'Caste / Social Reservation',
        message: `Reserved specifically for ${rules.castes.join(', ')} categories. Candidate is ${profile.caste}.`
      });
    } else {
      score += 20;
      breakdown.push({
        rule: 'Caste / Social Reservation',
        passed: true,
        detail: `Category ${profile.caste} is eligible`
      });
    }

    // 4. State of Domicile
    const isAllIndia = rules.states.includes('ALL');
    const stateMatches = isAllIndia || rules.states.includes(profile.state);

    if (!stateMatches) {
      disqualifications.push({
        rule: 'State Domicile',
        message: `Restricted to permanent residents of ${rules.states.join(', ')}. Candidate domicile is ${profile.state}.`
      });
    } else {
      score += 20;
      breakdown.push({
        rule: 'State Domicile',
        passed: true,
        detail: isAllIndia ? 'Open to all Indian states/UTs' : `Verified domicile: ${profile.state}`
      });
    }

    // 5. Degree / Educational Program
    const degreePassed = rules.degrees.includes('ALL') || 
                         rules.degrees.some(d => profile.degree.toLowerCase().includes(d.toLowerCase()));

    if (!degreePassed) {
      disqualifications.push({
        rule: 'Enrolled Degree',
        message: `Applicable to ${rules.degrees.join(', ')} only. Current enrollment: ${profile.degree}.`
      });
    } else {
      score += 15;
      breakdown.push({
        rule: 'Enrolled Degree',
        passed: true,
        detail: `Course ${profile.degree} is recognized for this scheme`
      });
    }

    // 6. Academic GPA / Percentage Merit
    const studentGpa = Number(profile.gpa) || 0;
    const gpaPassed = studentGpa >= rules.minGpa;

    if (!gpaPassed) {
      disqualifications.push({
        rule: 'Academic Merit Cut-off',
        message: `Minimum required GPA is ${rules.minGpa}. Current GPA is ${studentGpa}.`
      });
    } else {
      score += 20;
      breakdown.push({
        rule: 'Academic Merit Cut-off',
        passed: true,
        detail: `GPA ${studentGpa} exceeds minimum benchmark of ${rules.minGpa}`
      });
    }

    const isMatch = disqualifications.length === 0;

    return {
      isMatch,
      matchScore: isMatch ? Math.min(100, score) : Math.max(0, score - (disqualifications.length * 20)),
      breakdown,
      disqualifications
    };
  }

  /**
   * Filters and ranks an array of scholarships against a student profile.
   * @param {Object} profile 
   * @param {Array} scholarshipsList 
   * @returns {Object} { qualifying: [], partial: [], totalEvaluated: number }
   */
  function matchAll(profile, scholarshipsList) {
    const qualifying = [];
    const partial = [];

    scholarshipsList.forEach(scheme => {
      const evaluation = evaluateScholarship(profile, scheme);
      const enriched = {
        ...scheme,
        isMatch: evaluation.isMatch,
        matchScore: evaluation.matchScore,
        breakdown: evaluation.breakdown,
        disqualifications: evaluation.disqualifications
      };

      if (evaluation.isMatch) {
        qualifying.push(enriched);
      } else {
        partial.push(enriched);
      }
    });

    // Sort qualifying by Match Score descending, then Award Amount descending
    qualifying.sort((a, b) => b.matchScore - a.matchScore || b.awardAmount - a.awardAmount);

    return {
      qualifying,
      partial,
      totalEvaluated: scholarshipsList.length
    };
  }

  return {
    evaluateScholarship,
    matchAll
  };
})();

// Export for Node/CommonJS environment if running in server test
if (typeof module !== 'undefined' && module.exports) {
  module.exports = MatcherEngine;
}
