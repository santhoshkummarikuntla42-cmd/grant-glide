# GrantGlide: ScholarQuest 🎓
### Intelligent Indian Scholarship Matching & Document Readiness Engine
*Full Stack Web Development Mini-Project / Hackathon Solution*

---

## 📌 1. Problem Statement & Social Context
Deserving college students from underprivileged, rural, and marginalized backgrounds in India frequently miss out on government and private philanthropic scholarships totaling **crores of rupees** every year. The root causes include:
1. **Information Fragmentation:** Information is scattered across dozens of disparate central portals (NSP, AICTE, UGC), state welfare portals (Telangana ePASS, AP Jnanabhumi, Karnataka SSP, MahaDBT), and private CSR foundations (Reliance, Tata Trusts, Kotak, HDFC).
2. **Complex Composite Eligibility Rules:** Overlapping constraints involving caste reservations (SC/ST/BC/OBC/EWS), annual family income ceilings (₹1.5L to ₹8L), state domicile requirements, gender reservations, and academic GPA cut-offs confuse applicants.
3. **Application Rejection due to Expired / Missing Documents:** A student may qualify academically, but gets rejected when the deadline arrives because their **Income Certificate** (which in most Indian states is valid for only one financial year) has expired and revenue authorities (Tahsildar / MeeSeva / e-District) take 7–15 days to issue renewals.
4. **Policy Conflict & Dual-Availing Disqualifications:** Many students apply blindly to multiple government schemes without realizing that central guidelines strictly prohibit claiming concurrent tuition fee reimbursements from both Central and State government portals simultaneously.

---

## 🎯 2. Project Objective
**ScholarQuest** solves this problem by delivering:
- An **Intelligent Demographic & Academic Intake System** evaluating multi-criteria parameters.
- A **Predicate-Based Matching Algorithm Engine** outputting a personalized feed with match scores.
- A **Real-Time Application Deadline Countdown Tracker** with pulsing urgency badges (`< 7 Days Critical`, `< 15 Days Urgent`, `< 30 Days Warning`).
- An **Interactive Document Readiness Checklist** normalizing state-specific naming aliases (e.g., *MeeSeva* in TS/AP, *e-District* in UP, *Nadakacheri* in Karnataka) with status toggles (`3/5 Ready`).
- A **Document Expiration Pre-Warning System** flagging certificates expiring within 30 days to prompt timely renewal from local revenue authorities.
- A **Saved & Applied Applications Pipeline** with automated **Dual-Availing Policy Conflict Warnings**.
- A **Financial Aid Deficit Calculator** that recommends an optimal, legally compliant stack of 1 Government Tuition Waiver + 1 Private CSR Grant.
- A **WhatsApp Deadline Alert Bot Simulator** and **Regional Multilingual Support** (English, हिन्दी, తెలుగు).

---

## 💻 3. Technology Stack & File Architecture
The project strictly separates languages and follows clean, humanized, modular software engineering practices:

```
fsd-mini-project2/
├── index.html                   # Semantic HTML5 UI layout & accessible modals
├── package.json                 # Express backend dependencies & scripts
├── README.md                    # Comprehensive project documentation & viva defense
│
├── css/
│   └── style.css                # Custom CSS variables, Flexbox, Grid, urgency badges, animations
│
├── js/
│   ├── app.js                   # Master UI coordinator, event handling & demo preset loader
│   ├── matcher.js               # Multi-criteria rule evaluation engine (AND/OR boolean predicates)
│   ├── countdown.js             # Real-time live countdown timer & urgency classification
│   ├── documents.js             # Interactive document checklist, state aliases & expiration tracker
│   ├── tracker.js               # Applications pipeline (Kanban) & policy conflict detector
│   ├── calculator.js            # Financial aid deficit calculator & optimal scholarship stacker
│   ├── simulator.js             # WhatsApp mobile notification simulator
│   └── i18n.js                  # Regional language translation engine (English, Hindi, Telugu)
│
├── data/
│   ├── scholarships.json        # Database of 32 authentic Indian scholarships with deep metadata
│   ├── documents-schema.json    # Canonical document taxonomy & state-specific naming aliases
│   └── user_applications.json   # Local persistent store for student application records
│
└── server/
    ├── server.js                # Express REST API server providing endpoints
    └── dataStore.js             # JSON database persistence & retrieval layer
```

---

## ⚙️ 4. Key Engineering Modules & Logic

### A. Multi-Criteria Matching Engine (`js/matcher.js`)
Evaluates student attributes against composite scholarship rules structured as predicate trees:
$$\text{Income} \le \text{maxIncome} \quad\land\quad \text{Caste} \in \text{allowedCastes} \quad\land\quad \text{State} \in (\text{allowedStates} \cup \{\text{ALL}\}) \quad\land\quad \text{GPA} \ge \text{minGpa}$$
- **Match Score Algorithm:** Computes a transparent, weighted 0–100% score based on Income compliance (25%), Academic GPA (25%), Caste/Reservation compliance (20%), State Domicile (20%), and Degree Level (10%).
- Provides itemized transparency breakdown showing exactly which criteria passed and which failed.

### B. Live Deadline Countdown Tracker (`js/countdown.js`)
- Runs a high-performance 1-second interval calculating exact time remaining (`Days : Hours : Mins : Secs`).
- Dynamically assigns color-coded urgency classifications:
  - 🔴 **CRITICAL DEADLINE** (`< 7 Days`): Pulsing red animation with urgent action tag.
  - 🟠 **URGENT** (`7–14 Days`): High-priority orange warning.
  - 🟡 **CLOSING SOON** (`15–30 Days`): Amber alert.
  - 🟢 **ACTIVE / OPEN** (`> 30 Days`): Standard open status.

### C. State-Specific Document Normalization (`data/documents-schema.json` & `js/documents.js`)
Students from different states refer to the same document by different portal names. ScholarQuest maps canonical categories to state aliases:
| Canonical Document | Telangana / AP Alias | Karnataka Alias | Uttar Pradesh Alias |
|---|---|---|---|
| **Proof of Income** | MeeSeva Income Certificate (Tahsildar) | Nadakacheri Form-G | e-District Aay Praman Patra (आय प्रमाण पत्र) |
| **Caste / Community** | MeeSeva Integrated Community Memo | Nadakacheri Form-D/F | e-District Jati Praman Patra (जाति प्रमाण पत्र) |
| **Domicile / Residence** | Nativity Memo / 4th–10th Study Proof | Nadakacheri Resident Cert | Nivas Praman Patra (निवास प्रमाण पत्र) |

### D. Document Expiration Alert System
Flags certificates expiring in **< 30 days** (such as Tahsildar-issued Income Certificates). Warns the student with actionable advice: *"Income certificates expire after 1 financial year. Local revenue authorities take 7–10 days to re-certify; renew on MeeSeva immediately."*

### E. Dual-Availing Policy Conflict Detector (`js/tracker.js`)
When an applicant bookmarks or moves multiple government schemes into their active pipeline (e.g., Central Sector Scheme + State Post-Matric Fee Reimbursement), the system detects the violation:
> ⚠️ **Policy Conflict Detected:** Simultaneous Central and State Government full tuition fee subsidies are prohibited under Ministry of Education guidelines.
> **Recommended Solution:** Avail your State ePASS for 100% tuition reimbursement + pair with a private foundation grant (e.g., Reliance Foundation or Kotak Kanya) which specifically allows supplemental maintenance funding!

### F. Financial Aid Deficit Calculator (`js/calculator.js`)
Calculates:
$$\text{Net Deficit} = (\text{Tuition} + \text{Hostel} + \text{Supplies}) - \text{Family Capacity}$$
Automatically packages an **Optimal Non-Conflicting Scholarship Stack** (1 Government Scheme + 1 Private CSR Grant) to cover up to 100% of the deficit legally.

---

## 🚀 5. How to Run the Project

### Option A: Zero-Dependency Standalone Mode (Easiest & Instant)
Because ScholarQuest uses clean Vanilla JavaScript and relative data loading, you can run it directly:
1. Double click `index.html` or right-click `index.html` and select **"Open with Chrome / Edge / Firefox"**.
2. Or open the folder in VS Code and click **"Go Live"** (Live Server extension).
3. The application runs immediately with full interactive capabilities!

### Option B: Node.js Express REST Backend Mode
If running with the full-stack Express server:
```bash
# 1. Open terminal in the project directory
cd c:\Users\Admin\Desktop\fsd-mini-project2

# 2. Install dependencies
npm install

# 3. Start the Express server
npm start
```
Open your browser and navigate to:
```
http://localhost:3000
```

---

## 🎬 6. Step-by-Step Demo Walkthrough (For Professor Evaluation)

To demonstrate the exact scenario described in the Hackathon Problem Brief:

1. **Open the Web Application:**
   Observe the clean navigation header, the **Professor Demo Preset** banner, and the multi-criteria student intake form.
2. **Click the Demo Preset Button:**
   Click **"✨ Load Professor Demo Preset"** in the top blue banner.
   - Demographic values are populated:
     - Gender: **Female**
     - Domicile State: **Telangana**
     - Social Category: **BC (Backward Class / OBC)**
     - Annual Family Income: **₹1,50,000 (1.5 Lakhs)**
     - Enrolled Degree: **B.Tech (Engineering)**
     - Current Academic GPA: **8.5**
3. **Observe the Filtered Feed:**
   - The multi-criteria rule engine evaluates all 32 authentic schemes down to the qualifying schemes, including:
     1. **AICTE Pragati Scholarship for Girls** (₹50,000 / year) — **12 Days Remaining** (Urgent Badge)
     2. **Telangana State ePASS Post-Matric Scholarship (BC/EBC)** (₹35,000 - Full Tuition Fee Reimbursement) — **18 Days Remaining**
     3. **Reliance Foundation Undergraduate Scholarship** (Up to ₹2,00,000) — **24 Days Remaining**
     4. **Kotak Kanya Scholarship for Meritorious Girls** (₹1,50,000 / year) — **7 Days Remaining** (Critical Badge)
4. **Inspect Interactive Document Readiness:**
   - Look at the **AICTE Pragati Scholarship** card:
   - Notice the document readiness bar showing **3/5 Ready**.
   - Notice the yellow warning badge: **"⚠️ 1 Document Needs Renewal (Income Certificate)"**.
5. **Open Document Readiness Modal:**
   - Click the **"📋 Checklist (3/5)"** button on the card.
   - See the 3 ready documents (Bonafide, Caste Certificate, 12th Marksheet).
   - See the **MeeSeva Income Certificate** highlighted in yellow with the notice:
     *"⚠️ Expiration Warning: Certificate expires in 8 days. Issued by Tahsildar. Submit renewal on MeeSeva immediately."*
   - Click **"Mark Ready"** or simulate uploading a new certificate; watch the readiness meter jump from **3/5 (60%)** to **4/5 (80%)** in real time!
6. **Test Policy Conflict Warning:**
   - Go to the **"My Applications"** tab.
   - Bookmark both **"AICTE Pragati"** (Central Government) and **"Telangana ePASS"** (State Government).
   - Observe the **Policy Conflict Banner** immediately appear in red/amber with a detailed compliance explanation and suggested remedy!
7. **Test Stretch Features:**
   - **Financial Aid Calculator Tab:** Input tuition and hostel expenses; see the deficit and recommended 1 Government + 1 Private CSR bundle.
   - **WhatsApp Alert Bot Tab:** Enter a mobile number and click **"Send Simulated Test Alert"** to see a realistic WhatsApp mobile message preview with active countdowns and document renewal alerts.
   - **Regional Language Toggle:** Switch the top right dropdown to **हिन्दी** or **తెలుగు**; observe scholarship summaries translate instantly!

---

## 🎓 7. Viva / Oral Defense Questions & Answers

**Q1: Why did you structure scholarship eligibility rules as predicate trees instead of simple database queries?**
> *Answer:* Scholarship criteria in India involve composite nested logic (e.g., "Candidate must be Female AND (State is Telangana OR Scheme is All-India) AND (Income <= 1.5L if BC OR Income <= 2.5L if SC) AND GPA >= 8.0"). A predicate tree evaluator in JavaScript evaluates rules modularly, provides itemized failure reasons ("Why am I ineligible?"), and avoids rigid database schema migrations.

**Q2: How does the system handle differing document naming conventions across states?**
> *Answer:* Through canonical document normalization. We define core canonical types (`income_cert`, `caste_cert`, `domicile_cert`) in `data/documents-schema.json`, and map them to state-specific naming aliases (`MeeSeva` for Telangana/AP, `Nadakacheri` for Karnataka, `e-District` for UP). The UI displays the familiar regional name to the student based on their selected domicile state.

**Q3: How does the Dual-Availing policy conflict detector protect students from rejection?**
> *Answer:* Central portals like the National Scholarship Portal (NSP) cross-verify candidate Aadhaar numbers with Public Financial Management System (PFMS) records. If a student claims tuition fees from both a Central scheme and a State fee reimbursement scheme, both applications can be flagged for fraud or rejected. Our system flags this conflict proactively and recommends applying for state tuition reimbursement plus a non-conflicting private foundation grant (e.g. Reliance or Kotak) for living costs.

**Q4: How does the countdown timer work in real time without causing browser lag?**
> *Answer:* Instead of re-rendering entire card DOM structures every second, `CountdownEngine.startLiveTicking()` runs a lightweight `setInterval` that only mutates text content in the specific `.digit-days`, `.digit-hours`, `.digit-minutes`, and `.digit-seconds` span tags using data attributes (`data-deadline`).

---

## 📜 8. Author & Academic Submission
- **Project Name:** GrantGlide: ScholarQuest
- **Course / Topic:** Full Stack Web Development Mini Project (FSD)
- **Year / Semester:** Academic Year 2026-2027
- **License:** MIT License — Open for Educational & Non-Profit Use
