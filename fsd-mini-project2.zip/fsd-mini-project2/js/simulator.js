/**
 * ScholarQuest - WhatsApp Deadline Alert Simulator
 * 
 * Simulates mobile push/instant messaging alerts delivered to underprivileged
 * students and their parents, ensuring deadlines and expiring documents
 * are not missed due to lack of portal access.
 */

const WhatsAppSimulator = (() => {

  /**
   * Generates formatted WhatsApp alert text.
   */
  function generateAlertMessage({ studentName, studentState, schemes, expiringDocCount }) {
    const name = studentName || 'Student';
    const state = studentState || 'Telangana';

    let msg = `*🎓 ScholarQuest Scholarship Alert (${state})*\n\n`;
    msg += `Namaste *${name}*,\nHere is your real-time scholarship deadline summary:\n\n`;

    if (schemes && schemes.length > 0) {
      schemes.slice(0, 3).forEach((s, idx) => {
        msg += `*${idx + 1}. ${s.title}*\n`;
        msg += `   💰 Award: *${s.awardFormatted}*\n`;
        msg += `   ⏳ Deadline: *${s.deadlineDaysFromNow || 12} Days Remaining*\n`;
        msg += `   🌐 Portal: ${s.portalUrl}\n\n`;
      });
    } else {
      msg += `• You have active eligible schemes awaiting document upload.\n\n`;
    }

    if (expiringDocCount > 0) {
      msg += `*⚠️ DOCUMENT URGENT ACTION:*\n`;
      msg += `Your *Income Certificate* expires in less than 30 days! Please apply for renewal at your nearest *MeeSeva / Citizen Center* to prevent rejection.\n\n`;
    }

    msg += `📲 Track live status & checklist on *GrantGlide*: https://scholarquest.edu\n`;
    msg += `_Powered by ScholarQuest National Aid Engine. Reply HELP for assistance._`;

    return msg;
  }

  /**
   * Simulates dispatching the alert and renders interactive phone preview.
   */
  function renderPhonePreview(containerId, alertData) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const messageText = generateAlertMessage(alertData);
    // Replace newlines with <br> for HTML preview
    const formattedHtml = messageText
      .replace(/\*(.*?)\*/g, '<strong>$1</strong>')
      .replace(/_(.*?)_/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');

    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    container.innerHTML = `
      <div class="whatsapp-card">
        <div class="wa-header">
          <div class="wa-avatar">
            <span>🎓</span>
          </div>
          <div class="wa-info">
            <h4>ScholarQuest Alert Bot</h4>
            <span class="wa-sub">Official Scholarship Notification Service</span>
          </div>
          <div class="wa-verified">✓</div>
        </div>
        <div class="wa-body">
          <div class="wa-message-bubble">
            <div class="wa-content">${formattedHtml}</div>
            <div class="wa-meta">
              <span class="wa-time">${currentTime}</span>
              <span class="wa-ticks">✓✓</span>
            </div>
          </div>
        </div>
        <div class="wa-footer">
          <span class="wa-tag">🔔 Scheduled to dispatch via WhatsApp Cloud API</span>
        </div>
      </div>
    `;
  }

  return {
    generateAlertMessage,
    renderPhonePreview
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = WhatsAppSimulator;
}
