/**
 * ScholarQuest - Interactive Document Readiness & Expiration Alert System
 * 
 * Features:
 * - Canonical document taxonomy mapping to state-specific naming aliases
 * - Per-scholarship checklist calculation with live readiness meter (e.g., 3/5 Ready)
 * - Expiration Alert Engine: Flags certificates expiring within 30 days
 * - Upload simulator & status toggles (Ready, Needs Renewal, Missing)
 */

const DocumentManager = (() => {
  // Canonical document registry with state aliases
  let canonicalDocsMap = {};

  // Persistent student document locker state
  // Default values pre-configured to match the Professor Demo scenario:
  // 3/5 documents ready, with Income Certificate highlighted in yellow ('Needs Renewal')
  const defaultDocumentLocker = {
    income_cert: {
      status: 'renewal', // 'ready', 'renewal', 'missing'
      fileName: 'MeeSeva_Income_2025_TS.pdf',
      expiryDate: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 8 days remaining
      issuingAuthority: 'Tahsildar / MeeSeva Portal',
      notes: 'Issued previous financial year. Valid until current month end.'
    },
    caste_cert: {
      status: 'ready',
      fileName: 'TS_OBC_Community_Cert.pdf',
      expiryDate: '2028-06-30',
      issuingAuthority: 'Revenue Divisional Officer (RDO)',
      notes: 'Integrated caste and community certificate.'
    },
    bonafide_cert: {
      status: 'ready',
      fileName: 'College_Bonafide_2026.pdf',
      expiryDate: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      issuingAuthority: 'Principal, College of Engineering',
      notes: 'Valid for current academic semester.'
    },
    marksheet_12th: {
      status: 'ready',
      fileName: 'Intermediate_Final_MarksMemo.pdf',
      expiryDate: '2099-12-31',
      issuingAuthority: 'State Board of Intermediate Education',
      notes: 'Permanent marks memo.'
    },
    domicile_cert: {
      status: 'missing',
      fileName: null,
      expiryDate: null,
      issuingAuthority: 'MeeSeva / Revenue Inspector',
      notes: 'Pending upload or local residence certificate.'
    },
    bank_passbook: {
      status: 'ready',
      fileName: 'SBI_Passbook_Aadhaar_Seeded.pdf',
      expiryDate: '2099-12-31',
      issuingAuthority: 'State Bank of India',
      notes: 'NPCI Aadhaar mapping active.'
    },
    aadhaar_card: {
      status: 'ready',
      fileName: 'eAadhaar_UIDAI.pdf',
      expiryDate: '2099-12-31',
      issuingAuthority: 'UIDAI',
      notes: 'Verified.'
    },
    fee_receipt: {
      status: 'missing',
      fileName: null,
      expiryDate: null,
      issuingAuthority: 'College Accounts Section',
      notes: 'Challan fee receipt.'
    }
  };

  let studentLocker = { ...defaultDocumentLocker };

  /**
   * Loads documents schema from data file.
   */
  async function init(docsData) {
    if (docsData && docsData.canonicalDocuments) {
      docsData.canonicalDocuments.forEach(doc => {
        canonicalDocsMap[doc.id] = doc;
      });
    }

    // Try reading saved locker from localStorage
    const saved = localStorage.getItem('scholarquest_doc_locker');
    if (saved) {
      try {
        studentLocker = JSON.parse(saved);
      } catch (e) {
        studentLocker = { ...defaultDocumentLocker };
      }
    }
  }

  /**
   * Resets locker to Demo preset
   */
  function resetToDemoPreset() {
    studentLocker = JSON.parse(JSON.stringify(defaultDocumentLocker));
    // Set income cert to 8 days from now
    studentLocker.income_cert.expiryDate = new Date(Date.now() + 8 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    saveLocker();
  }

  function saveLocker() {
    localStorage.setItem('scholarquest_doc_locker', JSON.stringify(studentLocker));
  }

  /**
   * Resolves canonical document name to state-specific alias.
   * e.g., Telangana -> 'MeeSeva Income Certificate (issued by Tahsildar)'
   */
  function resolveDocAlias(docId, studentState = 'Telangana') {
    const meta = canonicalDocsMap[docId];
    if (!meta) {
      return {
        name: docId.replace(/_/g, ' ').toUpperCase(),
        authority: 'Competent Authority',
        tips: 'Provide valid official copy.'
      };
    }

    let alias = meta.canonicalName;
    if (meta.stateAliases) {
      if (meta.stateAliases[studentState]) {
        alias = meta.stateAliases[studentState];
      } else if (meta.stateAliases['Default']) {
        alias = meta.stateAliases['Default'];
      }
    }

    return {
      id: meta.id,
      canonicalName: meta.canonicalName,
      displayName: alias,
      category: meta.category,
      tips: meta.tips,
      requiresAnnualRenewal: meta.requiresAnnualRenewal
    };
  }

  /**
   * Evaluates document readiness for a specific scholarship scheme.
   * @param {Object} scheme 
   * @param {string} studentState 
   * @returns {Object} { totalRequired, readyCount, renewalCount, missingCount, percentage, items: [] }
   */
  function evaluateSchemeReadiness(scheme, studentState = 'Telangana') {
    const requiredDocIds = scheme.requiredDocuments || [];
    const items = [];
    let readyCount = 0;
    let renewalCount = 0;
    let missingCount = 0;

    requiredDocIds.forEach(docId => {
      const docDef = resolveDocAlias(docId, studentState);
      const userDoc = studentLocker[docId] || {
        status: 'missing',
        fileName: null,
        expiryDate: null
      };

      // Check for impending expiration (< 30 days)
      let isExpiringSoon = false;
      let daysUntilExpiry = null;

      if (userDoc.expiryDate) {
        const expMs = new Date(userDoc.expiryDate).getTime();
        const diffDays = Math.ceil((expMs - Date.now()) / (1000 * 60 * 60 * 24));
        daysUntilExpiry = diffDays;

        if (diffDays <= 30 && diffDays >= 0) {
          isExpiringSoon = true;
          // Upgrade status to renewal if marked ready but expiring
          if (userDoc.status === 'ready') {
            userDoc.status = 'renewal';
          }
        } else if (diffDays < 0) {
          userDoc.status = 'missing'; // Expired is treated as invalid
        }
      }

      if (userDoc.status === 'ready') {
        readyCount++;
      } else if (userDoc.status === 'renewal') {
        renewalCount++;
      } else {
        missingCount++;
      }

      items.push({
        id: docId,
        canonicalName: docDef.canonicalName,
        displayName: docDef.displayName,
        category: docDef.category,
        status: userDoc.status,
        fileName: userDoc.fileName,
        expiryDate: userDoc.expiryDate,
        daysUntilExpiry: daysUntilExpiry,
        isExpiringSoon: isExpiringSoon,
        tips: docDef.tips,
        requiresAnnualRenewal: docDef.requiresAnnualRenewal
      });
    });

    const totalRequired = requiredDocIds.length;
    const percentage = totalRequired > 0 ? Math.round((readyCount / totalRequired) * 100) : 100;

    return {
      schemeId: scheme.id,
      schemeTitle: scheme.title,
      totalRequired,
      readyCount,
      renewalCount,
      missingCount,
      percentage,
      items
    };
  }

  /**
   * Updates a document's status in student locker.
   */
  function updateDocument(docId, updateData) {
    if (!studentLocker[docId]) {
      studentLocker[docId] = {
        status: 'missing',
        fileName: null,
        expiryDate: null
      };
    }
    studentLocker[docId] = { ...studentLocker[docId], ...updateData };
    saveLocker();
  }

  /**
   * Returns all active expiration warnings across all student documents.
   */
  function getExpiringDocuments() {
    const warnings = [];
    Object.keys(studentLocker).forEach(docId => {
      const doc = studentLocker[docId];
      if (doc && doc.expiryDate) {
        const diffDays = Math.ceil((new Date(doc.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        if (diffDays <= 30) {
          const docDef = canonicalDocsMap[docId] || { canonicalName: docId };
          warnings.push({
            id: docId,
            name: docDef.canonicalName,
            daysLeft: diffDays,
            isExpired: diffDays < 0,
            expiryDate: doc.expiryDate,
            actionAdvice: `Issued by Revenue Authority. Apply for renewal at your nearest MeeSeva / e-District Citizen Service Center.`
          });
        }
      }
    });
    return warnings;
  }

  return {
    init,
    resetToDemoPreset,
    resolveDocAlias,
    evaluateSchemeReadiness,
    updateDocument,
    getExpiringDocuments,
    getLocker: () => studentLocker
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DocumentManager;
}
