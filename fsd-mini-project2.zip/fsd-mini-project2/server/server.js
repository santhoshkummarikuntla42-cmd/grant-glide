/**
 * ScholarQuest Express Server
 * 
 * Provides RESTful API endpoints for:
 * - Scholarship filtering & predicate-based matching
 * - Canonical document readiness schemas and state aliases
 * - User application pipeline tracking and dual-availing conflict detection
 * - Static file serving for the frontend
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const dataStore = require('./dataStore');

const app = express();
const PORT = process.env.PORT || 3000;

// Enable CORS and JSON body parsing
app.use(cors());
app.use(express.json());

// Serve static frontend assets from project root
app.use(express.static(path.join(__dirname, '..')));

/**
 * Evaluates whether a student profile matches a scholarship's criteria.
 * Returns { isMatch, matchScore, breakdown, disqualifications }
 */
function evaluateEligibility(profile, scheme) {
  const req = scheme.eligibility;
  const disqualifications = [];
  const breakdown = [];
  let scorePoints = 0;
  const maxPoints = 100;

  // 1. Gender Validation (Strict for women-only schemes)
  const isGenderMatch = req.genders.includes(profile.gender) || req.genders.includes('Other') || req.genders.includes('ALL');
  if (!isGenderMatch) {
    disqualifications.push(`Restricted to ${req.genders.join(', ')} applicants.`);
  } else {
    breakdown.push({ criteria: 'Gender Eligibility', status: 'Passed', detail: `Matches ${profile.gender}` });
  }

  // 2. Annual Income Ceiling
  const incomePassed = profile.annualIncome <= req.maxIncome;
  if (!incomePassed) {
    const diff = profile.annualIncome - req.maxIncome;
    disqualifications.push(`Income ₹${profile.annualIncome.toLocaleString('en-IN')} exceeds limit of ₹${req.maxIncome.toLocaleString('en-IN')} by ₹${diff.toLocaleString('en-IN')}.`);
  } else {
    scorePoints += 25;
    breakdown.push({
      criteria: 'Income Ceiling',
      status: 'Passed',
      detail: `₹${profile.annualIncome.toLocaleString('en-IN')} is within ₹${req.maxIncome.toLocaleString('en-IN')} cap`
    });
  }

  // 3. Social Category / Caste
  const castePassed = req.castes.includes(profile.caste) || req.castes.includes('ALL');
  if (!castePassed) {
    disqualifications.push(`Reserved for ${req.castes.join(', ')} categories.`);
  } else {
    scorePoints += 20;
    breakdown.push({ criteria: 'Social Category', status: 'Passed', detail: `Category ${profile.caste} accepted` });
  }

  // 4. State Domicile
  const statePassed = req.states.includes('ALL') || req.states.includes(profile.state);
  if (!statePassed) {
    disqualifications.push(`Domicile restricted to ${req.states.join(', ')} (Candidate is from ${profile.state}).`);
  } else {
    scorePoints += 20;
    breakdown.push({ criteria: 'State Domicile', status: 'Passed', detail: req.states.includes('ALL') ? 'All-India Open' : `Matches ${profile.state}` });
  }

  // 5. Degree / Level of Study
  const degreePassed = req.degrees.includes('ALL') || req.degrees.some(d => profile.degree.toLowerCase().includes(d.toLowerCase()));
  if (!degreePassed) {
    disqualifications.push(`Applicable for ${req.degrees.join(', ')} courses only.`);
  } else {
    scorePoints += 15;
    breakdown.push({ criteria: 'Degree Course', status: 'Passed', detail: `Course ${profile.degree} is eligible` });
  }

  // 6. Academic Performance (GPA / Percentage)
  const gpaPassed = profile.gpa >= req.minGpa;
  if (!gpaPassed) {
    disqualifications.push(`Minimum GPA required is ${req.minGpa} (Candidate has ${profile.gpa}).`);
  } else {
    scorePoints += 20;
    breakdown.push({ criteria: 'Academic Merit', status: 'Passed', detail: `GPA ${profile.gpa} exceeds required ${req.minGpa}` });
  }

  const isFullMatch = disqualifications.length === 0;

  return {
    isMatch: isFullMatch,
    matchScore: isFullMatch ? Math.min(100, scorePoints) : Math.max(0, scorePoints - (disqualifications.length * 20)),
    breakdown,
    disqualifications
  };
}

/**
 * Detects dual-availing policy conflicts among active applications.
 */
function checkPolicyConflicts(applications) {
  const warnings = [];
  const activeApps = applications.filter(a => ['Applied', 'Bookmarked', 'Under Review', 'Awarded'].includes(a.status));
  
  const hasCentralGovt = activeApps.some(a => a.policyConflictGroup === 'CENTRAL_GOVT_SCHEME' || a.policyConflictGroup === 'CENTRAL_POST_MATRIC');
  const hasStateGovt = activeApps.some(a => a.policyConflictGroup === 'STATE_EPASS_SCHEME');

  if (hasCentralGovt && hasStateGovt) {
    warnings.push({
      type: 'GOVERNMENT_DUAL_AVAILING_CONFLICT',
      severity: 'high',
      title: 'Policy Conflict: Simultaneous Central & State Tuition Claims Prohibited',
      message: 'You have active applications in both a Central Government Scheme (e.g. NSP/CSSS/AICTE) and a State ePASS Scheme. Most state guidelines prohibit availing two government tuition waivers concurrently. We recommend choosing your state tuition fee reimbursement plus a non-conflicting private foundation grant (e.g., Reliance Foundation or Kotak Kanya).'
    });
  }

  return warnings;
}

// ==========================================
// REST API ROUTES
// ==========================================

/**
 * GET /api/scholarships
 * Returns list of all scholarships with optional category or state filtering.
 */
app.get('/api/scholarships', (req, res) => {
  try {
    let scholarships = dataStore.getAllScholarships();
    const { category, state, search } = req.query;

    if (category && category !== 'ALL') {
      scholarships = scholarships.filter(s => s.category.toLowerCase() === category.toLowerCase() || s.schemeType.toLowerCase() === category.toLowerCase());
    }

    if (state && state !== 'ALL') {
      scholarships = scholarships.filter(s => s.eligibility.states.includes('ALL') || s.eligibility.states.includes(state));
    }

    if (search) {
      const q = search.toLowerCase();
      scholarships = scholarships.filter(s => 
        s.title.toLowerCase().includes(q) ||
        s.administeringBody.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q)
      );
    }

    res.json({
      success: true,
      count: scholarships.length,
      data: scholarships
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/match
 * Evaluates student demographic & academic profile against all scholarship predicate rules.
 */
app.post('/api/match', (req, res) => {
  try {
    const profile = req.body;
    
    // Fallback defaults for missing fields
    const normalizedProfile = {
      gender: profile.gender || 'Female',
      caste: profile.caste || 'OBC',
      annualIncome: Number(profile.annualIncome) || 150000,
      state: profile.state || 'Telangana',
      degree: profile.degree || 'B.Tech',
      gpa: Number(profile.gpa) || 8.5
    };

    const allScholarships = dataStore.getAllScholarships();
    const matched = [];
    const partialOrIneligible = [];

    allScholarships.forEach(scheme => {
      const evaluation = evaluateEligibility(normalizedProfile, scheme);
      const enhancedScheme = {
        ...scheme,
        matchScore: evaluation.matchScore,
        breakdown: evaluation.breakdown,
        disqualifications: evaluation.disqualifications
      };

      if (evaluation.isMatch) {
        matched.push(enhancedScheme);
      } else {
        partialOrIneligible.push(enhancedScheme);
      }
    });

    // Sort matched by match score descending, then award amount descending
    matched.sort((a, b) => b.matchScore - a.matchScore || b.awardAmount - a.awardAmount);

    res.json({
      success: true,
      evaluatedProfile: normalizedProfile,
      matchedCount: matched.length,
      matched: matched,
      ineligibleCount: partialOrIneligible.length,
      ineligible: partialOrIneligible
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/documents
 * Returns canonical document definitions and state-specific alias mapping.
 */
app.get('/api/documents', (req, res) => {
  try {
    const docs = dataStore.getAllDocuments();
    res.json({
      success: true,
      data: docs
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/applications
 * Returns saved applications and current policy conflict status.
 */
app.get('/api/applications', (req, res) => {
  try {
    const apps = dataStore.getUserApplications();
    const conflicts = checkPolicyConflicts(apps);
    res.json({
      success: true,
      count: apps.length,
      data: apps,
      conflicts: conflicts
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/applications
 * Saves or updates an application status in student pipeline.
 */
app.post('/api/applications', (req, res) => {
  try {
    const { scholarshipId, status, notes } = req.body;
    const allScholarships = dataStore.getAllScholarships();
    const scheme = allScholarships.find(s => s.id === scholarshipId);

    if (!scheme) {
      return res.status(404).json({ success: false, message: 'Scholarship scheme not found.' });
    }

    const apps = dataStore.getUserApplications();
    const existingIndex = apps.findIndex(a => a.id === scholarshipId);

    const appRecord = {
      id: scheme.id,
      title: scheme.title,
      awardFormatted: scheme.awardFormatted,
      awardAmount: scheme.awardAmount,
      policyConflictGroup: scheme.policyConflictGroup,
      status: status || 'Bookmarked',
      deadlineDaysFromNow: scheme.deadlineDaysFromNow,
      notes: notes || '',
      updatedAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      apps[existingIndex] = { ...apps[existingIndex], ...appRecord };
    } else {
      apps.push(appRecord);
    }

    dataStore.saveUserApplications(apps);
    const conflicts = checkPolicyConflicts(apps);

    res.json({
      success: true,
      message: `Scholarship "${scheme.title}" updated to status "${appRecord.status}".`,
      data: appRecord,
      conflicts: conflicts
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/applications/:id
 * Removes a saved application.
 */
app.delete('/api/applications/:id', (req, res) => {
  try {
    const { id } = req.params;
    let apps = dataStore.getUserApplications();
    apps = apps.filter(a => a.id !== id);
    dataStore.saveUserApplications(apps);

    const conflicts = checkPolicyConflicts(apps);

    res.json({
      success: true,
      message: 'Application removed successfully.',
      conflicts: conflicts
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * Health check endpoint
 */
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Start Express HTTP Server
app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🎓 GrantGlide: ScholarQuest Engine running!`);
  console.log(`🌐 Local Server: http://localhost:${PORT}`);
  console.log(`📡 REST API endpoints active:`);
  console.log(`   - GET  /api/scholarships`);
  console.log(`   - POST /api/match`);
  console.log(`   - GET  /api/documents`);
  console.log(`   - GET  /api/applications`);
  console.log(`====================================================`);
});
